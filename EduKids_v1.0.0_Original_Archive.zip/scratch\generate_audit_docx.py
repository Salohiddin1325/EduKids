import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def create_element(name):
    return OxmlElement(name)

def set_cell_background(cell, hex_color):
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>')
    cell._tc.get_or_add_tcPr().append(shd)

def set_cell_padding(cell, top=120, bottom=120, left=160, right=160):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'''
        <w:tcMar {nsdecls("w")}>
            <w:top w:w="{top}" w:type="dxa"/>
            <w:bottom w:w="{bottom}" w:type="dxa"/>
            <w:left w:w="{left}" w:type="dxa"/>
            <w:right w:w="{right}" w:type="dxa"/>
        </w:tcMar>
    ''')
    tcPr.append(tcMar)

def set_table_borders(table, color="D1D5DB", sz="4", val="single"):
    tblPr = table._tbl.tblPr
    borders = parse_xml(f'''
        <w:tblBorders {nsdecls("w")}>
            <w:top w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
            <w:bottom w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
            <w:left w:val="none"/>
            <w:right w:val="none"/>
            <w:insideH w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
            <w:insideV w:val="none"/>
        </w:tblBorders>
    ''')
    tblPr.append(borders)

def add_callout(doc, text, title=None, border_color="2563EB", bg_color="EFF6FF"):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    
    cell = tbl.cell(0, 0)
    cell.width = Inches(6.5)
    set_cell_background(cell, bg_color)
    set_cell_padding(cell, top=140, bottom=140, left=200, right=180)
    
    # Left thick border only
    borders = parse_xml(f'''
        <w:tcBorders {nsdecls("w")}>
            <w:top w:val="none"/>
            <w:left w:val="single" w:sz="24" w:space="0" w:color="{border_color}"/>
            <w:bottom w:val="none"/>
            <w:right w:val="none"/>
        </w:tcBorders>
    ''')
    cell._tc.get_or_add_tcPr().append(borders)
    
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    
    if title:
        run_title = p.add_run(f"📌 {title}\n")
        run_title.bold = True
        run_title.font.name = "Calibri"
        run_title.font.size = Pt(11)
        run_title.font.color.rgb = RGBColor.from_string(border_color)
        
    run_text = p.add_run(text)
    run_text.font.name = "Calibri"
    run_text.font.size = Pt(10.5)
    run_text.font.color.rgb = RGBColor(30, 41, 59)
    
    # Add small spacing after table
    sp_p = doc.add_paragraph()
    sp_p.paragraph_format.space_before = Pt(0)
    sp_p.paragraph_format.space_after = Pt(6)

def build_docx(output_path):
    doc = Document()
    
    # Margins: 1 inch (72 pt / 1440 dxa)
    for section in doc.sections:
        section.top_margin = Inches(0.9)
        section.bottom_margin = Inches(0.9)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.page_width = Inches(8.5)
        section.page_height = Inches(11.0)
        
        # Header / Footer
        footer = section.footer
        fp = footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        frun = fp.add_run("EduKids (Ёшлар Академияси) — Халқаро Эксперт Ҳисоботи | 2026")
        frun.font.name = "Calibri"
        frun.font.size = Pt(8.5)
        frun.font.color.rgb = RGBColor(148, 163, 184)
        
    # Set default style font
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Calibri'
    font.size = Pt(11)
    font.color.rgb = RGBColor(30, 41, 59) # Slate 800
    
    # ---------------------------------------------------------------------------
    # COVER / HEADER TITLE BLOCK
    # ---------------------------------------------------------------------------
    title_p = doc.add_paragraph()
    title_p.paragraph_format.space_before = Pt(10)
    title_p.paragraph_format.space_after = Pt(4)
    run_badge = title_p.add_run("СТРАТЕГИК ТАҲЛИЛ ВА ТАЪЛИМ АУДИТИ\n")
    run_badge.font.name = "Calibri"
    run_badge.font.size = Pt(10)
    run_badge.bold = True
    run_badge.font.color.rgb = RGBColor(37, 99, 235) # Blue 600
    
    run_main_title = title_p.add_run("EduKids (Ёшлар Академияси) Таълим Платформасининг Комплекс Аудити ва Хорижий Илғор Платформалар Билaн Таққосий Ҳисоботи")
    run_main_title.font.name = "Calibri"
    run_main_title.font.size = Pt(20)
    run_main_title.bold = True
    run_main_title.font.color.rgb = RGBColor(15, 23, 42) # Slate 900
    
    sub_p = doc.add_paragraph()
    sub_p.paragraph_format.space_before = Pt(4)
    sub_p.paragraph_format.space_after = Pt(16)
    sub_run = sub_p.add_run("Khan Academy Kids, Duolingo ABC, Prodigy Math, ABCmouse ва Brilliant.org стандартлари асосида таққослаш, камчиликларни аниқлаш ва платформани жаҳон даражасига олиб чиқиш бўйича таклифлар")
    sub_run.font.name = "Calibri"
    sub_run.font.size = Pt(11.5)
    sub_run.font.italic = True
    sub_run.font.color.rgb = RGBColor(71, 85, 105) # Slate 600
    
    # Metadata horizontal box
    meta_tbl = doc.add_table(rows=1, cols=4)
    meta_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    meta_tbl.autofit = False
    
    meta_items = [
        ("МАҲСУЛОТ", "EduKids v1.0.0"),
        ("МАҚОМИ", "Илмий-Амалий Аудит"),
        ("ҲУДУД / ҚАМРОВ", "Ўзбекистон / МДҲ"),
        ("САНА", "2026-йил")
    ]
    
    for idx, (lbl, val) in enumerate(meta_items):
        c = meta_tbl.cell(0, idx)
        c.width = Inches(1.62)
        set_cell_background(c, "F8FAFC")
        set_cell_padding(c, top=80, bottom=80, left=100, right=100)
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(0)
        r_lbl = p.add_run(f"{lbl}\n")
        r_lbl.font.size = Pt(7.5)
        r_lbl.font.bold = True
        r_lbl.font.color.rgb = RGBColor(100, 116, 139)
        r_val = p.add_run(val)
        r_val.font.size = Pt(9.5)
        r_val.font.bold = True
        r_val.font.color.rgb = RGBColor(15, 23, 42)
        
    set_table_borders(meta_tbl, color="E2E8F0", sz="4")
    
    doc.add_paragraph().paragraph_format.space_after = Pt(12)
    
    # ---------------------------------------------------------------------------
    # 1. ЭКСПЕРТ ХУЛОСАСИ ВА БАҲОЛАШ
    # ---------------------------------------------------------------------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(16)
    h1.paragraph_format.space_after = Pt(6)
    h1.paragraph_format.keep_with_next = True
    r = h1.add_run("1. Эксперт Хулосаси ва Умумий Кўрсаткичлар (Executive Summary)")
    r.font.name = "Calibri"
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = RGBColor(30, 58, 138) # Dark Navy
    
    p = doc.add_paragraph(
        "EduKids (Ёшлар Академияси) таълим портали — 3–12 ёшдаги болаларга инглиз тили, математика ва физика "
        "фанларини интерактив қумлоқлар (sandboxes), ўйинлар ва овозли ҳамроҳ орқали ўргатишга мўлжалланган миллий лойиҳадир. "
        "Лойиҳанинг бош меъморий концепцияси 100% Zero-Build (оғир фреймворкларсиз, Pure Vanilla HTML5/CSS3/JavaScript) ва "
        "Offline-First (интернетсиз мустақил ишлаш) тамойилига таянади."
    )
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(8)
    
    # Rating Table
    rate_tbl = doc.add_table(rows=8, cols=3)
    rate_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    rate_tbl.autofit = False
    
    headers = ["Йўналиш / Мезон", "Баҳо (10 балл)", "Ҳолати ва Эксперт Шарҳи"]
    col_widths = [Inches(2.2), Inches(1.1), Inches(3.2)]
    
    for c_idx, h_text in enumerate(headers):
        cell = rate_tbl.cell(0, c_idx)
        cell.width = col_widths[c_idx]
        set_cell_background(cell, "1E3A8A")
        set_cell_padding(cell, top=100, bottom=100, left=120, right=120)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        run = p.add_run(h_text)
        run.font.bold = True
        run.font.size = Pt(9.5)
        run.font.color.rgb = RGBColor(255, 255, 255)
        if c_idx == 1:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
    ratings_data = [
        ("Техник Меъморчилик (Architecture)", "9.0 / 10", "Оғир фреймворкларсиз, Web Audio API, PWA ва тўлиқ оффлайн ишлаш имконияти юқори."),
        ("Хавфсизлик ва Махфийлик (COPPA / Zero-PII)", "9.5 / 10", "Шахсий маълумотлар сақланмайди, 100% маҳаллий localStorage, тармоққа чиқмайди."),
        ("UI/UX ва Болалар Эргономикаси", "8.8 / 10", "Fredoka/Quicksand шрифтлари, тактил 3D тугмалар, Glassmorphism ва овозли реакциялар."),
        ("Ўйинлаштириш (Gamification)", "8.5 / 10", "XP, Юлдуз/Олмос иқтисодиёти, Astro-Shop 3D кийинтириш хонаси, Кунлик олов (Streak)."),
        ("Ота-оналар Воситалари (Parent Dashboard)", "7.5 / 10", "Арифметик PIN ҳимояси, ўрганилган вақт ва хатолар таҳлили мавжуд."),
        ("Аудио ва Талаффуз Баҳоси (Speech Tech)", "6.8 / 10", "Ўзбекча TTS ва овозли қидирув бор, аммо инглизча талаффузни баҳоловчи фонетик тизим йўқ."),
        ("Педагогик Мослашувчанлик (Adaptive Path)", "6.5 / 10", "3-5 ёш ва 9-12 ёшли болалар учун чегаралар ажратилмаган, адаптив кириш тести йўқ.")
    ]
    
    for r_idx, row_data in enumerate(ratings_data, start=1):
        bg = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            cell = rate_tbl.cell(r_idx, c_idx)
            cell.width = col_widths[c_idx]
            set_cell_background(cell, bg)
            set_cell_padding(cell, top=70, bottom=70, left=120, right=120)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.15
            run = p.add_run(val)
            run.font.size = Pt(9.0)
            if c_idx == 0:
                run.font.bold = True
                run.font.color.rgb = RGBColor(30, 41, 59)
            elif c_idx == 1:
                run.font.bold = True
                run.font.color.rgb = RGBColor(37, 99, 235)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                run.font.color.rgb = RGBColor(71, 85, 105)
                
    set_table_borders(rate_tbl, color="E2E8F0", sz="4")
    
    add_callout(
        doc,
        "EduKids платформаси техник тезлиги ва оффлайн ишлаш имконияти бўйича ҳатто АҚШ ва Европанинг йирик тизимларидан устун туради. Бироқ педагогик чуқурлик, ёш бўйича адаптивлик ва инглиз тили талаффузини таҳлил қилиш борасида дунё гигантларидан ўрганиш лозим бўлган муҳим жиҳатлар мавжуд.",
        title="Аудитнинг Асосий Эксперт Хулосаси",
        border_color="2563EB",
        bg_color="EFF6FF"
    )
    
    # ---------------------------------------------------------------------------
    # 2. ЖАҲОН ПЛАТФОРМАЛАРИ БИЛАН ҚИЁСИЙ ТАҲЛИЛ
    # ---------------------------------------------------------------------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(6)
    h1.paragraph_format.keep_with_next = True
    r = h1.add_run("2. Жаҳоннинг Етакчи Платформалари Билaн Таққосий Матрица")
    r.font.name = "Calibri"
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = RGBColor(30, 58, 138)
    
    doc.add_paragraph(
        "EduKids қуйидаги халқаро миқёсда тан олинган 5 та етакчи платформа билан солиштирилди:\n"
        "• Khan Academy Kids (АҚШ) — 2–8 ёш учун дунё стандарти, тўлиқ нотижорат адаптив кутубхона.\n"
        "• Duolingo / Duolingo ABC (АҚШ) — Тил ўрганиш ва фонетика бўйича энг кучли геймификация драйвери.\n"
        "• Prodigy Math (Канада) — Сюжетли RPG жанги орқали мактаб математикасини ўргатувчи фэнтези ўйини.\n"
        "• ABCmouse / Adventure Academy (Age of Learning) — 8,500+ машғулотни ўз ичига олган комплекс дастур.\n"
        "• Brilliant.org (АҚШ) — STEM, физика ва интерактив мантиқий симуляциялар етакчиси."
    ).paragraph_format.line_spacing = 1.15
    
    # Big Comparison Table
    bench_tbl = doc.add_table(rows=10, cols=6)
    bench_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    bench_tbl.autofit = False
    
    bench_headers = ["Таққослаш Мезони", "EduKids (Бизда)", "Khan Academy Kids", "Duolingo ABC", "Prodigy Math", "Brilliant.org"]
    b_widths = [Inches(1.5), Inches(1.1), Inches(1.0), Inches(1.0), Inches(0.95), Inches(0.95)]
    
    for c_idx, h_text in enumerate(bench_headers):
        cell = bench_tbl.cell(0, c_idx)
        cell.width = b_widths[c_idx]
        set_cell_background(cell, "0F172A")
        set_cell_padding(cell, top=90, bottom=90, left=80, right=80)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        run = p.add_run(h_text)
        run.font.bold = True
        run.font.size = Pt(8.5)
        run.font.color.rgb = RGBColor(255, 255, 255)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
    bench_rows = [
        ("Ёш Чегараси", "3–12 ёш", "2–8 ёш", "3–8 ёш", "6–14 ёш", "10+ ёш"),
        ("Фанлар Қамрови", "Инглиз, Математика, Физика", "Математика, Китобхонлик, Мантиқ", "Фақат инглиз тили фонетикаси", "Математика, Инглиз тили", "Физика, Математика, CS, Мантиқ"),
        ("Оффлайн Ишлаш", "100% Оффлайн (PWA + Web Audio)", "Қисман (фақат юкланган китоблар)", "Интернет талаб этилади", "Доимий интернет шарт", "Интернет талаб этилади"),
        ("Ўқитиш Методи", "Қумлоқ (Sandbox), тест, doska", "Адаптив чизиқли йўлак (Path)", "Фонологик бўғинлаш, аудио-такрор", "Сюжетли RPG қаҳрамон жанги", "Фаол интуитив эксперимент"),
        ("Талаффузни Текшириш", "Йўқ (фақат TTS синтез бор)", "Йўқ (аудио тинглаш бор)", "Бор (Фонемалар баҳоси)", "Йўқ", "Йўқ"),
        ("Интерактив Симуляция", "Бор (Каср пицца, Призма, Ток)", "Йўқ (оддий 2D)", "Йўқ", "Йўқ", "Жуда юқори симуляциялар"),
        ("AI Маскот Ҳамроҳ", "Бор (AstroBot: NLP + Gemini)", "Йўқ (статик персонаж)", "Йўқ (фақат эмоция)", "Йўқ", "Йўқ"),
        ("Ўзбек Тили", "100% Она тилимизда + RU", "Йўқ (Инглиз/Испан)", "Йўқ (Инглиз)", "Йўқ (Инглиз)", "Йўқ (Инглиз/Рус)"),
        ("Нархи / Модел", "Бепул / Pro симуляция", "100% Бепул", "100% Бепул", "Freemium ($59/йил)", "$13.49–$24.99/ой")
    ]
    
    for r_idx, row_data in enumerate(bench_rows, start=1):
        bg = "F1F5F9" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            cell = bench_tbl.cell(r_idx, c_idx)
            cell.width = b_widths[c_idx]
            set_cell_background(cell, bg)
            set_cell_padding(cell, top=60, bottom=60, left=70, right=70)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.1
            run = p.add_run(val)
            run.font.size = Pt(8.0)
            if c_idx == 0:
                run.font.bold = True
                run.font.color.rgb = RGBColor(30, 41, 59)
            elif c_idx == 1:
                run.font.bold = True
                run.font.color.rgb = RGBColor(37, 99, 235)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                run.font.color.rgb = RGBColor(71, 85, 105)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                
    set_table_borders(bench_tbl, color="CBD5E1", sz="4")
    
    doc.add_paragraph().paragraph_format.space_after = Pt(8)
    
    # ---------------------------------------------------------------------------
    # 3. ЧУҚУР МОДУЛЛИ АУДИТ ВА ТАҲЛИЛ
    # ---------------------------------------------------------------------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(6)
    h1.paragraph_format.keep_with_next = True
    r = h1.add_run("3. Платформанинг Чуқур Модулли Аудити (Deep Dive Audit)")
    r.font.name = "Calibri"
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = RGBColor(30, 58, 138)
    
    # 3.1
    h2 = doc.add_heading(level=2)
    h2.paragraph_format.space_before = Pt(10)
    h2.paragraph_format.space_after = Pt(4)
    h2.paragraph_format.keep_with_next = True
    r = h2.add_run("3.1. Техник Меъморчилик ва Код Сифати (Architecture & Code Quality)")
    r.font.name = "Calibri"
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.color.rgb = RGBColor(15, 23, 42)
    
    doc.add_paragraph(
        "✅ Ютуқлар:\n"
        "• Нол-боғлиқлик (Zero-Dependency): Лойиҳа ташқи оғир кутубхоналарсиз (React, Angular, Vue, Webpack, Vite) ишлайди. "
        "Бу кам қувватли қурилмаларда ва эски планшетларда веб-сайтнинг дақиқалар эмас, сониянинг учдан бир қисмида очилишини таъминлайди.\n"
        "• Web Audio API Синтези: Ҳар бир босиш, ғалаба садоси ва фон мусиқаси браузер ичида математик осцилляторлар ёрдамида оффлайн генерация қилинади. Тармоқдан бир байт ҳам овоз файли кўчириб олинмайди.\n"
        "• Киберхавфсизлик ва CSP (CYBERSECURITY.md): Content Security Policy мета-теглари, Zero-PII ва LocalStorage чегаралари тўғри созланган.\n\n"
        "⚠️ Аниқланган Кемтиклар:\n"
        "• Кўп болали оилалар қўлланмаган: LocalStorage фақат 1 та фаол фойдаланувчи учун мўлжалланган. Битта планшетда икки бола ўқиса, уларнинг юлдузлари ва даражалари чалкашиб кетади.\n"
        "• Ҳолатни қайта тиклаш (State Migration): LocalStorage формати ўзгарганда фойдаланувчининг аввалги юлдузлари ўчиб кетмаслиги учун автоматлаштирилган версиялаш (schema versioning) етишмайди."
    ).paragraph_format.line_spacing = 1.15
    
    # 3.2
    h2 = doc.add_heading(level=2)
    h2.paragraph_format.space_before = Pt(10)
    h2.paragraph_format.space_after = Pt(4)
    h2.paragraph_format.keep_with_next = True
    r = h2.add_run("3.2. Фанлар Модуллари ва Интерактив Таълим (Math, English, Physics)")
    r.font.name = "Calibri"
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.color.rgb = RGBColor(15, 23, 42)
    
    doc.add_paragraph(
        "📐 Математика Модули (MathKids):\n"
        "• fraction-sandbox.js — Касрлар қумлоғи ажойиб ишлайди. Пицца ва пирог бўлаклари болаларга абстракт рақамларни визуал кўриш имконини беради.\n"
        "• whiteboard.js — Чизма қоралама доскаси болаларга ўз фикрларини бармоқ билан ёзиб чиқаришга ёрдам беради.\n"
        "• Кемтик: 1-100 оралиғидаги қўшиш/айриш учун қадам-ба-қадам кўргазмали кўчириш (regrouping / ўнликдан ўтиш) анимацияси йўқ.\n\n"
        "🦁 Инглиз Тили Модули (KiddoLingo):\n"
        "• 100 та болалар сўзлари, 26 та ҳарф ва фоника овозлари, шарлар учириш ва сўз ясаш ўйинлари тўлиқ маҳаллийлаштирилган.\n"
        "• Кемтик: Сўзларни фақат ёзиш ва тинглаш бор, аммо боланинг овозли талаффузини таҳлил қилувчи алгоритм мавжуд эмас.\n\n"
        "⚛️ Физика Модули (PhysicsKids):\n"
        "• physics-sandbox.js ва experiments.js — Оғирлик кучи, сузиш ёки чўкиш (Архимед қонуни), ёруғлик призмаси ва оддий ток занжирини визуаллаштириш болаларда табиий илмий қизиқиш уйғотади."
    ).paragraph_format.line_spacing = 1.15
    
    # 3.3
    h2 = doc.add_heading(level=2)
    h2.paragraph_format.space_before = Pt(10)
    h2.paragraph_format.space_after = Pt(4)
    h2.paragraph_format.keep_with_next = True
    r = h2.add_run("3.3. Ўйинлаштириш ва AI Ҳамроҳ (Gamification & AstroBot)")
    r.font.name = "Calibri"
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.color.rgb = RGBColor(15, 23, 42)
    
    doc.add_paragraph(
        "• GamificationHub: 6 та даража, XP йиғиш, Кунлик сирли қути (Daily Mystery Box), Кунлик олов (Streak) болани ҳар куни қайтиб киришга ундайди.\n"
        "• Astro-Shop 3D Studio: Юлдузлар эвазига бош кийимлар, ниқоблар, скафандрлар ва сеҳрли уй ҳайвонларини (pet_dragon, pet_bunny) сотиб олиш болаларга завқ бағишлайди.\n"
        "• AstroBot AI Ҳамроҳ: Кунига 10 та савол квотаси (Aqlli Bola Rejimi) педагогик жиҳатдан мукаммал ўйланган. Оффлайн 40+ табиат ва физика мавзуларида болаларча аналогиялар келтиради. Интернет бўлганида эса Google Gemini API билан кенгаяди."
    ).paragraph_format.line_spacing = 1.15
    
    # ---------------------------------------------------------------------------
    # 4. АНИҚЛАНГАН АСОСИЙ КАМЧИЛИКЛАР
    # ---------------------------------------------------------------------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(6)
    h1.paragraph_format.keep_with_next = True
    r = h1.add_run("4. Тизимдаги Асосий Камчиликлар ва Ривожланиш Кемтиклари")
    r.font.name = "Calibri"
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = RGBColor(185, 28, 28) # Red 700
    
    gaps_tbl = doc.add_table(rows=7, cols=3)
    gaps_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    gaps_tbl.autofit = False
    
    g_widths = [Inches(1.8), Inches(1.1), Inches(3.6)]
    g_headers = ["Аниқланган Муаммо", "Муҳимлик", "Таъсири ва Оқибати"]
    
    for c_idx, h_text in enumerate(g_headers):
        cell = gaps_tbl.cell(0, c_idx)
        cell.width = g_widths[c_idx]
        set_cell_background(cell, "991B1B")
        set_cell_padding(cell, top=80, bottom=80, left=100, right=100)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        run = p.add_run(h_text)
        run.font.bold = True
        run.font.size = Pt(9.0)
        run.font.color.rgb = RGBColor(255, 255, 255)
        if c_idx == 1:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
    gaps_data = [
        ("Ёш бўйича дифференциация йўқлиги", "КРИТИК (Юқори)", "4 яшар бола мураккаб физикани кўриб қўрқиб кетади, 11 яшар бола 1–10 санашдан зерикади."),
        ("Инглиз тили талаффузини баҳолаш йўқлиги", "ЮҚОРИ", "Бола сўзни нотўғри айтса ҳам сезмайди, оғзаки нутқ кўникмаси мустаҳкамланмайди."),
        ("Кўп болали оилалар профили йўқлиги", "ЮҚОРИ", "Битта хонадондаги ака-сингиллар битта планшетда бир-бирининг натижаларини бузиб қўяди."),
        ("Тизимли эможиларга боғлиқлик", "ЎРТА", "Эможилар Windows, Android ва iOS да турлича (баъзан қора-оқ) кўриниб, визуал бренд йўқолади."),
        ("Кўз саломатлиги ва танаффус таймери йўқлиги", "ЎРТА", "Бола 30-40 дақиқа тўхтовсиз экранга тикилиб қолиши ота-оналарда хавотир уйғотади."),
        ("Интервал қайтариш (Spaced Repetition) йўқлиги", "ЎРТА", "Бола хато қилган саволларни тизим эслаб қолмайди ва эртаси куни қайта сўрамайди.")
    ]
    
    for r_idx, row_data in enumerate(gaps_data, start=1):
        bg = "FEF2F2" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            cell = gaps_tbl.cell(r_idx, c_idx)
            cell.width = g_widths[c_idx]
            set_cell_background(cell, bg)
            set_cell_padding(cell, top=65, bottom=65, left=100, right=100)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.15
            run = p.add_run(val)
            run.font.size = Pt(8.5)
            if c_idx == 0:
                run.font.bold = True
                run.font.color.rgb = RGBColor(15, 23, 42)
            elif c_idx == 1:
                run.font.bold = True
                run.font.color.rgb = RGBColor(185, 28, 28)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                run.font.color.rgb = RGBColor(71, 85, 105)
                
    set_table_borders(gaps_tbl, color="FCA5A5", sz="4")
    
    doc.add_paragraph().paragraph_format.space_after = Pt(10)
    
    # ---------------------------------------------------------------------------
    # 5. СТРАТЕГИК ТАКЛИФЛАР ВА ЙЎЛ ХАРИТАСИ
    # ---------------------------------------------------------------------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(6)
    h1.paragraph_format.keep_with_next = True
    r = h1.add_run("5. Платформани Жаҳон Стандартига Кўтариш Бўйича 7 Та Таклиф")
    r.font.name = "Calibri"
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = RGBColor(30, 58, 138)
    
    proposals = [
        ("1-Таклиф: Ёш Бўйича 3 Табақали Адаптив Йўлак (Age-Adaptive Tracks)",
         "Платформани 3 та ёш каналига ажратиш:\n"
         "• 👶 Кичкинтойлар (3–5 ёш): Санаш (1–10), ранглар, ҳайвонлар товушлари. Матнсиз, фақат визуал ва овозли.\n"
         "• 👦 Бошланғич Босқич (6–8 ёш): Фоника, карра жадвали, қўшиш-айриш, сузиш-чўкиш физикаси.\n"
         "• 🧑 Катта Босқич (9–12 ёш): Касрлар лабораторияси, геометрия, ток занжири, оптика призмаси.\n"
         "Илк киришда Космо 3 та енгил савол бериб ёки ота-она танлови билан мос контентни автоматик филтрлайди."),
         
        ("2-Таклиф: Фонетика ва Талаффузни Баҳоловчи Интерактив Движок (Speech Grader)",
         "Web Speech Recognition API ёрдамида боланинг инглизча талаффузини жонли баҳолаш:\n"
         "• Экранда масалан: 'APPLE' сўзи чиқади.\n"
         "• Зиппи тулки уни тўғри айтади, сўнг микрофон тугмаси ёнади.\n"
         "• Бола гапирганда тизим талаффуз аниқлигини ҳисоблаб, 3 та юлдузча ва овозли рағбатлантириш беради."),
         
        ("3-Таклиф: Кўп Болали Оилалар Профили ва Маълумотларни Экспорт Қилиш",
         "Бир хонадондаги бир нечта бола учун мустақил сақлаш тизими:\n"
         "• 'localStorage'да 'profiles: [{ id: 'child_1', name: 'Алихон', age: 5, stars: 30 }, { id: 'child_2', name: 'Мадина', age: 9, stars: 85 }]' шаклида профиллар тузиш.\n"
         "• Ҳедердаги аватарни босиб, 1 сонияда иккинчи боланинг профилига ўтиш.\n"
         "• Ота-оналар учун 'JSON Захира нусхаси' (Backup/Restore) тугмаси, бу маълумотлар ўчиб кетмаслигини кафолатлайди."),
         
        ("4-Таклиф: Кўз Саломатлиги ва 'Космо Билaн Дам Олиш' Таймери",
         "20 дақиқалик узлуксиз дарсдан сўнг экранда мулойим нафас олувчи парда ҳосил бўлади:\n"
         "• Космо экранда пайдо бўлиб: 'Биз 20 дақиқа ажойиб ўқидик! Энди кўзларимизни узоққа қаратиб, 5 марта пирпиратамиз!' деб машқ кўрсатади.\n"
         "• 60 сониядан сўнг дарс яна давом этади. Бу халқаро 'Kids-Safe' стандартларига 100% мос келади."),
         
        ("5-Таклиф: Оффлайн Интервал Қайтариш Алгоритми (Spaced Repetition / Leitner)",
         "Бола хато қилган математик мисоллар ёки сўзларни тизим хотирасида сақлаб, 1-кун, 3-кун ва 7-кундан сўнг қайта такрорлатади. Бу билимларнинг узоқ муддатли хотирада 85% дан ортиқ сақланишини таъминлайди."),
         
        ("6-Таклиф: Чоп Этиладиган Оффлайн Иш Варақлари (Printable PDF Worksheets)",
         "Pure CSS '@media print' воситасида қўшимча кутубхоналарсиз болалар учун қоғоз машқлар яратиш:\n"
         "• Касрларни бўяш вазифалари (пицца ва пироглар).\n"
         "• Карра жадвали бўйича боғламали лабиринтлар.\n"
         "• Инглиз ҳарфларини нуқталар бўйлаб чизиш (handwriting tracing) варақлари."),
         
        ("7-Таклиф: Муаллифлик Векторли SVG Қаҳрамонлари Бренд Экотизими",
         "Стандарт операцион тизим эможиларидан (🐱, 🤖, 🦊, 🦉) воз кечиб, EduKids учун шахсий муаллифлик векторли SVG маскотларини киритиш. Бу бренд қийматини кўтаради ва хоҳлаган арзон Android ёки Windows компьютерида ҳам бир хил премиум кўринади.")
    ]
    
    for title, desc in proposals:
        h2 = doc.add_heading(level=2)
        h2.paragraph_format.space_before = Pt(12)
        h2.paragraph_format.space_after = Pt(4)
        h2.paragraph_format.keep_with_next = True
        r = h2.add_run(title)
        r.font.name = "Calibri"
        r.font.size = Pt(11.5)
        r.font.bold = True
        r.font.color.rgb = RGBColor(15, 23, 42)
        
        p = doc.add_paragraph(desc)
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(6)
        
    # ---------------------------------------------------------------------------
    # 6. АМАЛГА ОШИРИШ ЙЎЛ ХАРИТАСИ ВА БОСҚИЧЛАР
    # ---------------------------------------------------------------------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(6)
    h1.paragraph_format.keep_with_next = True
    r = h1.add_run("6. Амалга Ошириш Босқичлари ва Тавсия Этилган Муддатлар")
    r.font.name = "Calibri"
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = RGBColor(30, 58, 138)
    
    road_tbl = doc.add_table(rows=5, cols=4)
    road_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    road_tbl.autofit = False
    
    r_widths = [Inches(0.8), Inches(2.2), Inches(1.3), Inches(2.2)]
    r_headers = ["Босқич", "Вазифа ва Йўналиш", "Мўлжалланган Вақт", "Кутилаётган Натижа"]
    
    for c_idx, h_text in enumerate(r_headers):
        cell = road_tbl.cell(0, c_idx)
        cell.width = r_widths[c_idx]
        set_cell_background(cell, "1E3A8A")
        set_cell_padding(cell, top=80, bottom=80, left=90, right=90)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        run = p.add_run(h_text)
        run.font.bold = True
        run.font.size = Pt(9.0)
        run.font.color.rgb = RGBColor(255, 255, 255)
        if c_idx in [0, 2]:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
    roadmap_data = [
        ("I Босқич", "Кўп болали профиллар ва Ёш филтри", "3–4 кун", "Ака-укалар мустақил юлдуз йиғади, ёшга мос интерфейс очилади."),
        ("II Босқич", "Кўз саломатлиги ва Космо таймери", "1–2 кун", "20 дақиқада бир кўз машқи чиқади, ота-оналар ишончи кескин ошади."),
        ("III Босқич", "Инглизча талаффуз синовчиси (Speech Grader)", "4–5 кун", "Инглиз тили модули Duolingo ABC даражасидаги фоникага эга бўлади."),
        ("IV Босқич", "Чоп этиладиган PDF иш варақлари", "2–3 кун", "Оффлайн қалам ва қоғоз машқлари билан моторика бирлашади.")
    ]
    
    for r_idx, row_data in enumerate(roadmap_data, start=1):
        bg = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            cell = road_tbl.cell(r_idx, c_idx)
            cell.width = r_widths[c_idx]
            set_cell_background(cell, bg)
            set_cell_padding(cell, top=65, bottom=65, left=90, right=90)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.15
            run = p.add_run(val)
            run.font.size = Pt(8.5)
            if c_idx == 0:
                run.font.bold = True
                run.font.color.rgb = RGBColor(37, 99, 235)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif c_idx == 1:
                run.font.bold = True
                run.font.color.rgb = RGBColor(15, 23, 42)
            elif c_idx == 2:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run.font.color.rgb = RGBColor(100, 116, 139)
            else:
                run.font.color.rgb = RGBColor(71, 85, 105)
                
    set_table_borders(road_tbl, color="CBD5E1", sz="4")
    
    doc.add_paragraph().paragraph_format.space_after = Pt(16)
    
    # Final Sign-off block
    sign_tbl = doc.add_table(rows=1, cols=2)
    sign_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    sign_tbl.autofit = False
    
    sc0 = sign_tbl.cell(0, 0)
    sc0.width = Inches(3.25)
    set_cell_background(sc0, "F1F5F9")
    set_cell_padding(sc0, top=100, bottom=100, left=120, right=120)
    p0 = sc0.paragraphs[0]
    p0.paragraph_format.space_after = Pt(0)
    p0.paragraph_format.line_spacing = 1.15
    r0_1 = p0.add_run("Ҳисобот Тайёрловчи:\n")
    r0_1.font.size = Pt(8.5)
    r0_1.font.bold = True
    r0_1.font.color.rgb = RGBColor(100, 116, 139)
    r0_2 = p0.add_run("EduKids Маҳсулот ва Таълим Аудити Гуруҳи\n(Yoshlar Akademiyasi EdTech Lab)")
    r0_2.font.size = Pt(9.5)
    r0_2.font.color.rgb = RGBColor(30, 41, 59)
    
    sc1 = sign_tbl.cell(0, 1)
    sc1.width = Inches(3.25)
    set_cell_background(sc1, "F1F5F9")
    set_cell_padding(sc1, top=100, bottom=100, left=120, right=120)
    p1 = sc1.paragraphs[0]
    p1.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p1.paragraph_format.space_after = Pt(0)
    p1.paragraph_format.line_spacing = 1.15
    r1_1 = p1.add_run("Ҳужжат Идентификатори:\n")
    r1_1.font.size = Pt(8.5)
    r1_1.font.bold = True
    r1_1.font.color.rgb = RGBColor(100, 116, 139)
    r1_2 = p1.add_run("EDUKIDS-AUDIT-2026-V1\nТошкент, Ўзбекистон")
    r1_2.font.size = Pt(9.5)
    r1_2.font.color.rgb = RGBColor(30, 41, 59)
    
    set_table_borders(sign_tbl, color="E2E8F0", sz="4")
    
    doc.save(output_path)
    print(f"Hujjat muvaffaqiyatli saqlandi: {output_path}")

if __name__ == "__main__":
    out_dir = r"c:\Users\Salohiddin\OneDrive\Desktop\yosh bolachalar uchun"
    out_file = os.path.join(out_dir, "EduKids_Audit_va_Xalqaro_Taqqoslash_Hisoboti.docx")
    build_docx(out_file)
