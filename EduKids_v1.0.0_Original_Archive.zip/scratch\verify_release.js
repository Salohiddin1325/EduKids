import fs from 'fs';
import path from 'path';

console.log('🚀 === EDUKIDS FINAL RELEASE VERIFICATION (v1.0) ===\n');

let issues = 0;

// 1. Verify manifest.json
console.log('📦 1. Checking PWA manifest.json...');
if (!fs.existsSync('manifest.json')) {
  console.error('❌ manifest.json does not exist!');
  issues++;
} else {
  try {
    const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
    console.log(`✅ manifest.json valid JSON (name: "${manifest.name}")`);
    for (const icon of manifest.icons || []) {
      const iconPath = icon.src.replace(/^\.\//, '');
      if (fs.existsSync(iconPath)) {
        console.log(`   ✓ Icon found: ${iconPath}`);
      } else {
        console.error(`   ❌ Missing icon: ${iconPath}`);
        issues++;
      }
    }
  } catch (err) {
    console.error('❌ Failed to parse manifest.json:', err.message);
    issues++;
  }
}

// 2. Verify all 4 HTML pages and their local links / assets
console.log('\n🌐 2. Checking HTML Pages and Assets Links...');
const pages = [
  'index.html',
  'math/index.html',
  'english/index.html',
  'physics/index.html'
];

pages.forEach(page => {
  if (!fs.existsSync(page)) {
    console.error(`❌ Page missing: ${page}`);
    issues++;
    return;
  }
  const content = fs.readFileSync(page, 'utf8');
  const dir = path.dirname(page);

  // Match href and src
  const linkMatches = [...content.matchAll(/(?:href|src)=["']([^"']+)["']/g)];
  for (const m of linkMatches) {
    const link = m[1];
    // Skip external URLs, anchors, data, blob
    if (link.startsWith('http://') || link.startsWith('https://') || link.startsWith('#') || link.startsWith('data:') || link.startsWith('blob:')) {
      continue;
    }
    const resolvedPath = path.resolve(dir, link.split('?')[0].split('#')[0]);
    if (fs.existsSync(resolvedPath)) {
      // Ok
    } else {
      console.error(`   ❌ In ${page}: Asset not found -> "${link}" (resolved to: ${resolvedPath})`);
      issues++;
    }
  }
  console.log(`✅ Page verified: ${page} (all local scripts, stylesheets and links exist)`);
});

// 3. Verify CSS Imports
console.log('\n🎨 3. Checking CSS @import paths...');
const cssFiles = [
  'shared/shared.css',
  'shared/subscription.css',
  'shared/level-map.css',
  'shared/chatbot.css',
  'math/css/style.css',
  'english/css/style.css',
  'physics/css/style.css'
];

cssFiles.forEach(css => {
  if (!fs.existsSync(css)) return;
  const content = fs.readFileSync(css, 'utf8');
  const dir = path.dirname(css);
  const importMatches = [...content.matchAll(/@import\s+(?:url\(['"]?([^'")]+)['"]?\)|['"]([^'"]+)['"])/g)];
  for (const m of importMatches) {
    const imp = m[1] || m[2];
    if (imp.startsWith('http')) continue;
    const resolved = path.resolve(dir, imp);
    if (!fs.existsSync(resolved)) {
      console.error(`   ❌ In ${css}: Missing @import "${imp}"`);
      issues++;
    }
  }
});
console.log('✅ All CSS @imports resolved successfully.');

// 4. Verify Service Worker precache list
console.log('\n⚙️ 4. Checking sw.js precache asset list...');
const swContent = fs.readFileSync('sw.js', 'utf8');
const precacheMatches = swContent.match(/const PRECACHE_ASSETS = \[([\s\S]*?)\];/);
if (precacheMatches) {
  const rawList = precacheMatches[1];
  const items = [...rawList.matchAll(/['"]([^'"]+)['"]/g)].map(m => m[1]);
  let missingCount = 0;
  items.forEach(item => {
    if (item === './') return;
    const cleanItem = item.replace(/^\.\//, '');
    if (!fs.existsSync(cleanItem)) {
      console.error(`   ❌ sw.js precache item missing: ${item}`);
      missingCount++;
      issues++;
    }
  });
  if (missingCount === 0) {
    console.log(`✅ All ${items.length} sw.js precache items physically exist in workspace.`);
  }
}

// 5. Final Report
console.log('\n' + '='.repeat(50));
if (issues === 0) {
  console.log('🏆 100% PRODUCTION READY: ZERO ISSUES DETECTED!');
  console.log('All criteria for Release v1.0 have been met.');
} else {
  console.error(`❌ Total issues detected: ${issues}`);
  process.exit(1);
}
