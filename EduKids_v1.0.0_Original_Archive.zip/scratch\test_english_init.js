import fs from 'fs';

// Mock DOM
const documentMock = {
  documentElement: {
    setAttribute: () => {},
    classList: { add: () => {}, remove: () => {} }
  },
  body: {
    style: {},
    appendChild: () => {}
  },
  getElementById: (id) => {
    return {
      id,
      addEventListener: () => {},
      classList: { add: () => {}, remove: () => {}, toggle: () => {} },
      style: {},
      innerHTML: '',
      textContent: '',
      querySelectorAll: () => [],
      querySelector: () => null,
      dataset: {}
    };
  },
  querySelectorAll: () => [],
  querySelector: () => null,
  addEventListener: () => {}
};

global.window = {
  addEventListener: () => {},
  localStorage: {
    getItem: () => null,
    setItem: () => {}
  },
  document: documentMock,
  speechSynthesis: {
    speak: () => {},
    cancel: () => {},
    getVoices: () => []
  }
};
global.document = documentMock;
global.localStorage = global.window.localStorage;

try {
  console.log('Loading data.js...');
  eval(fs.readFileSync('english/js/data.js', 'utf8').replace('const VOCABULARY_DATA', 'global.VOCABULARY_DATA'));

  console.log('Loading shared/audio.js...');
  eval(fs.readFileSync('shared/audio.js', 'utf8'));

  console.log('Loading english/js/audio.js...');
  eval(fs.readFileSync('english/js/audio.js', 'utf8'));

  console.log('Loading english/js/confetti.js...');
  eval(fs.readFileSync('english/js/confetti.js', 'utf8'));

  console.log('Loading english/js/exercises.js...');
  eval(fs.readFileSync('english/js/exercises.js', 'utf8'));

  console.log('Loading english/js/games.js...');
  eval(fs.readFileSync('english/js/games.js', 'utf8'));

  console.log('Loading english/js/app.js...');
  eval(fs.readFileSync('english/js/app.js', 'utf8'));

  console.log('✅ All files loaded without syntax or top-level execution errors!');
  console.log('typeof window.openWordModal:', typeof global.window.openWordModal);
  console.log('typeof window.playWordSpeech:', typeof global.window.playWordSpeech);
} catch (err) {
  console.error('❌ Error during script execution:', err);
}
