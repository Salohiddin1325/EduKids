import fs from 'fs';

let dataCode = fs.readFileSync('english/js/data.js', 'utf8');
dataCode = dataCode.replace('const VOCABULARY_DATA', 'global.VOCABULARY_DATA');
eval(dataCode);

let failedWords = [];

global.VOCABULARY_DATA.forEach(word => {
  try {
    const audioBtnText = '🔊 Eshitish / Listen';
    const exLabel = '✨ Namuna Jumla / Example Sentence:';
    
    // Evaluate the template literal exactly as in openWordModal
    const html = `
    <button class="modal-close-btn" onclick="closeWordModal()">✕</button>
    
    <div class="modal-hero-visual" style="background: radial-gradient(circle, ${word.color}44, ${word.color}11);">
      <span class="modal-big-emoji">${word.emoji}</span>
      <button class="big-audio-btn" onclick="playWordSpeech('${word.id}', '${word.word}')">
        ${audioBtnText}
      </button>
    </div>

    <div class="modal-info-panel">
      <div class="modal-title-row">
        <h2 class="modal-en-word">${word.word}</h2>
        <span class="modal-phonetic">${word.phonetic}</span>
      </div>

      <div class="modal-definitions">
        <div class="def-block en-def">
          <span class="badge-mini en">English</span>
          <p>${word.definitionEn}</p>
        </div>
        <div class="def-block uz-def" style="cursor: pointer;" onclick="if(window.uzbekSpeech) window.uzbekSpeech.speak('${word.uzbek}. ${word.definitionUz.replace(/'/g, "\\'")}')" title="O‘zbekcha talaffuzni eshitish">
          <span class="badge-mini uz">O‘zbekcha 🔊</span>
          <p><strong>${word.uzbek}:</strong> ${word.definitionUz}</p>
        </div>
        <div class="def-block ru-def">
          <span class="badge-mini ru">Русский</span>
          <p><strong>${word.russian}:</strong> ${word.definitionRu}</p>
        </div>
      </div>

      <div class="modal-example-card">
        <h4>${exLabel}</h4>
        <div class="example-en-sentence">
          <p>"${word.exampleEn}"</p>
          <button class="speaker-btn mini-speaker" onclick="window.soundEngine.speak('${word.exampleEn.replace(/'/g, "\\'")}')">🔊</button>
        </div>
        <p class="example-sub-sentence" style="cursor: pointer;" onclick="if(window.uzbekSpeech) window.uzbekSpeech.speak('${word.exampleUz.replace(/'/g, "\\'")}')" title="O‘zbekcha jumla talaffuzi">🇺🇿 ${word.exampleUz} 🔊</p>
        <p class="example-sub-sentence">🇷🇺 ${word.exampleRu}</p>
      </div>
    </div>
  `;
  } catch (err) {
    failedWords.push({ id: word.id, err: err.message });
  }
});

console.log('Failed template evaluation count:', failedWords.length);
