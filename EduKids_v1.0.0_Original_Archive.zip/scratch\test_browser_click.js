import http from 'http';

async function main() {
  console.log('Connecting to Chrome DevTools on port 9222...');
  
  // Get active targets
  const versionRes = await fetch('http://127.0.0.1:9222/json/list');
  const targets = await versionRes.json();
  console.log('Targets:', targets.map(t => t.url));
  
  // Find or create page target
  let target = targets.find(t => t.type === 'page');
  if (!target) {
    const newTargetRes = await fetch('http://127.0.0.1:9222/json/new?http://localhost:8080/english/index.html');
    target = await newTargetRes.json();
  } else {
    // Navigate existing target
  }
  
  console.log('Using target:', target.webSocketDebuggerUrl);
  const ws = new WebSocket(target.webSocketDebuggerUrl);

  let id = 1;
  const pending = new Map();

  function send(method, params = {}) {
    return new Promise((resolve, reject) => {
      const msgId = id++;
      pending.set(msgId, { resolve, reject });
      ws.send(JSON.stringify({ id: msgId, method, params }));
    });
  }

  ws.onopen = async () => {
    console.log('WebSocket connected to Chrome DevTools!');
    
    // Enable console & runtime
    await send('Runtime.enable');
    await send('Page.enable');
    
    // Navigate
    console.log('Navigating to english page...');
    await send('Page.navigate', { url: 'http://localhost:8080/english/index.html' });

    // Wait 2 seconds for load
    await new Promise(r => setTimeout(r, 2000));

    // Test clicking the first word card
    console.log('Triggering click on first word card...');
    const res = await send('Runtime.evaluate', {
      expression: `(() => {
        const card = document.querySelector('.word-card');
        if (!card) return 'No word-card found!';
        const cardId = card.id;
        card.click();
        const modal = document.getElementById('word-modal');
        return {
          cardId: cardId,
          modalFound: !!modal,
          modalClasses: modal ? modal.className : null,
          modalHtmlLength: modal ? modal.innerHTML.length : 0,
          modalDisplay: modal ? window.getComputedStyle(modal).display : null,
          lastSpeech: window._lastSpeechText || 'none'
        };
      })()`,
      returnByValue: true
    });

    console.log('Evaluate result after click:', res.result.value);

    // Wait a little bit
    await new Promise(r => setTimeout(r, 1000));
    
    ws.close();
    process.exit(0);
  };

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.method === 'Runtime.consoleAPICalled') {
      console.log('BROWSER CONSOLE:', msg.params.type, msg.params.args.map(a => a.value || a.description).join(' '));
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      console.error('BROWSER EXCEPTION:', msg.params.exceptionDetails.text, msg.params.exceptionDetails.exception?.description);
    }
    if (msg.id && pending.has(msg.id)) {
      const { resolve } = pending.get(msg.id);
      pending.delete(msg.id);
      resolve(msg);
    }
  };
}

main().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
