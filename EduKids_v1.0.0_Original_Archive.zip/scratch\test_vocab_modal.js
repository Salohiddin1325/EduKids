import fs from 'fs';

let dataCode = fs.readFileSync('english/js/data.js', 'utf8');
dataCode = dataCode.replace('const VOCABULARY_DATA', 'global.VOCABULARY_DATA');
eval(dataCode);

const categories = {};
global.VOCABULARY_DATA.forEach(w => {
  categories[w.category] = (categories[w.category] || 0) + 1;
});
console.log('Categories in data.js:', categories);
