import fs from 'fs';
import path from 'path';

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    if (file === 'node_modules' || file.startsWith('.')) return;
    const full = path.join(dir, file);
    const stat = fs.statSync(full);
    if (stat && stat.isDirectory()) results = results.concat(walk(full));
    else if (file.endsWith('.css')) results.push(full);
  });
  return results;
}

const cssFiles = walk('.');
let errors = 0;

cssFiles.forEach(f => {
  const lines = fs.readFileSync(f, 'utf8').split('\n');
  lines.forEach((line, i) => {
    if (line.includes('backdrop-filter:') && !line.includes('-webkit-')) {
      const prev = lines[i - 1] || '';
      const next = lines[i + 1] || '';
      if (!prev.includes('-webkit-backdrop-filter') && !next.includes('-webkit-backdrop-filter')) {
        console.log(`[Missing -webkit-backdrop-filter] ${f}:${i + 1} -> ${line.trim()}`);
        errors++;
      }
    }
    if (line.includes('user-select:') && !line.includes('-webkit-')) {
      const prev = lines[i - 1] || '';
      const next = lines[i + 1] || '';
      if (!prev.includes('-webkit-user-select') && !next.includes('-webkit-user-select')) {
        console.log(`[Missing -webkit-user-select] ${f}:${i + 1} -> ${line.trim()}`);
        errors++;
      }
    }
  });
});

console.log(`CSS Safari check complete: ${errors} missing prefixes found.`);
if (errors > 0) process.exit(1);
