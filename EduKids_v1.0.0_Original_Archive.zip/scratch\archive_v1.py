import os
import zipfile
import datetime

archive_filename = "EduKids_v1.0.0_Original_Archive.zip"
exclude_dirs = {'.git', 'node_modules', '__pycache__'}
exclude_extensions = {'.zip'}

root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
zip_path = os.path.join(root_dir, archive_filename)

print(f"Ildiz papka: {root_dir}")
print(f"Arxiv yaratilmoqda: {zip_path}")

file_count = 0
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Filter out directories
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        for f in filenames:
            if f.endswith('.zip') or f == archive_filename:
                continue
            full_path = os.path.join(dirpath, f)
            rel_path = os.path.relpath(full_path, root_dir)
            zipf.write(full_path, rel_path)
            file_count += 1

print(f"Архив муваффақиятли яратилди: {archive_filename} ({file_count} та файл)")
